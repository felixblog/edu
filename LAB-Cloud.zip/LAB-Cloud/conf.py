# LOCALE
home = r"H:\Didattica\scuola\anno-2023-2024\Cloud\4.Modulo-Flask\LAB-Cloud\\"
# REMOTO
#home = r"/corso/LAB-Cloud/"
