import sqlite3
import conf
from flask import *


def tuttiVelisti():

    conn = sqlite3.connect(f"{conf.home}Lab2.db")

#### Per MySQL ####
#   conn = mysql.connector.connect(user='dbusr_corso1', password='dbusr$corso1', host='database-1.cv0sgaqamf5n.eu-west-3.rds.amazonaws.com', database='Velisti')    

    cur = conn.cursor()
    cur.execute("select vnome, punteggio from Velisti")
    elenco = cur.fetchall()
    return render_template('tuttiVelisti.html', velisti = elenco)
