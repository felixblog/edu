from flask import *
import conf
import sqlite3
import puntiBianca
import tuttiVelisti


# Per eseguire il programma in LOCALE;
# C:\...\> flask --app labCloud.py run --host=0.0.0.0 --port=8081
# URL: http://localhost:8081/lab 

# Per eseguire il programma in REMOTO;
# $ flask --app labCloud.py run --host=0.0.0.0 --port=8081
# URL: http://ec2-user@ec2-15-237-90-19.eu-west-3.compute.amazonaws.com:8081/lab

app = Flask("__main__", template_folder=f'{conf.home}templates', static_folder=f'{conf.home}static')

@app.route("/lab/tuttiVelisti")
def tutti_Velisti():
    return tuttiVelisti.tuttiVelisti()

@app.route("/lab/puntiBianca")
def punti_Bianca():
    return puntiBianca.puntiBianca()

@app.route("/lab")
def index():
    return render_template('homeVelisti.html')

if __name__ == "__main__":
    app.run(debug = True)


